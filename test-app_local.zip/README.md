# Test App

This app is for showing that c_group_rules don't work with the ScaleIT-transfer-App.

